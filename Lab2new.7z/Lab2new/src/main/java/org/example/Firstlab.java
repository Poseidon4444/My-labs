package org.example;

import com.sun.jndi.toolkit.dir.SearchFilter;

import java.time.Duration;

public class Firstlab {
    private WebDriver chromeDriver;

    private static final String baseurl = "https://comfy.ua/";

    @BeforeClass(alwaysRun = true)
    public void setUp(){
        WebDriverManager.chromedriver().setup;
        ChromeOptions chromeOptions = new ChromeOptions ();

        chromeOptions.addargument("--start-fullscreen");

        chromeOptions.setimplictWaitTimeout(Duration.ofSeconds(15));
        this.chromeDriver = new ChromeDriver(chromeOptions);
    }
    @BeforeMethod
    public void preconditions(){
        ChromeDriver.get(baseurl);
    }
    @AfterClass(alwaysRun = true)
    public void tearDown() { chromeDriver.qit();}
    @Test
    public void testHeaderExists() {
        WebElement header = chromeDriver.findElement(Byid("header"));
        Assert.assertNotNull(header);
    }
    @TEst
    public void testClickOnmobile(){
        WebElement formobileButton = chromeDriver.findElement(By.xpath("/html/body/div/div/div[4]/div/div/div[1]/div[2]/div/div[1]/a"));
        Assert.assertNotNull(formobileButton);
        formobileButton.click();
        Assert.assertNotEquals(chromeDriver.getCurrentUrl(), baseurl);

    }
    public void testSearchField(){
        String searchPageUrl = "https://comfy.ua/ua/";
        chromeDriver.get(baseurl + searchPageUrl);

        WebElement searchField = chromeDriver.FindElement(By.tagname('input'));

        Assert.assertNotNull(searchField);

        System.out.println( String.format("Name attribute: %s", searchField.getAttribute("name")));

        String inputValue = "Телефон";
        SearchField.sendKeys(inputValue);

        Assert.assertEquals(searchField.getText(), inputValue);

        searchField.sendkeys(Keys.ENTER);

        Assert.assertNotEquals(chromeDriver.getCurrentUrl(), studentPageUrl);
    }
    private static WebElement findElementByXPath(String xpath) {
        findElementByXPath("//div[@class='header-bottom-wrapper']//a[text()='ноутбуки']").click();
        return driver.findElement(By.xpath(xpath));
    }
    private static void assertElementExists(By locator) {
        assertElementExists(By.cssSelector(".product-item"));
        int count = driver.findElements(locator).size();
        assert count > 0;
    }
}